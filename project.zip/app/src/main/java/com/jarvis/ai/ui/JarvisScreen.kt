package com.jarvis.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.ai.MainViewModel
import com.jarvis.ai.core.JarvisState
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Cyan = Color(0xFF00E5FF)
private val Mono = FontFamily.Monospace

@Composable
fun JarvisScreen(vm: MainViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    var micOk by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }

    val state = ui.demo ?: if (ui.online) JarvisState.VEILLE else JarvisState.HORS_LIGNE

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }
    val date = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.FRENCH))
        .replaceFirstChar { it.uppercase() }
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"))

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("J.A.R.V.I.S.", color = Cyan, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 6.sp)
        Spacer(Modifier.height(10.dp))
        Text(time, color = Color.White, fontFamily = Mono, fontSize = 34.sp, fontWeight = FontWeight.Light)
        Text(date, color = Cyan.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 12.sp)

        Spacer(Modifier.height(18.dp))
        HoloCore(state, Modifier.fillMaxWidth(0.82f))
        Spacer(Modifier.height(8.dp))
        Text(state.label, color = state.color, fontFamily = Mono, fontSize = 20.sp, letterSpacing = 5.sp)
        if (ui.demo != null) {
            Text("démo visuelle en cours", color = Color.Gray, fontFamily = Mono, fontSize = 11.sp)
        }

        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chip("RÉSEAU", if (ui.online) "EN LIGNE" else "HORS LIGNE", ui.online, Modifier.weight(1f))
            val b = ui.battery
            val battery = if (b.percent < 0) "N/D" else "${b.percent} %" + if (b.charging) " · charge" else ""
            Chip("BATTERIE", battery, b.percent < 0 || b.percent > 15, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chip(
                "MICRO",
                if (micOk) "AUTORISÉ · inactif" else "TOUCHER POUR AUTORISER",
                micOk,
                Modifier.weight(1f)
            ) { if (!micOk) launcher.launch(Manifest.permission.RECORD_AUDIO) }
            Chip("IA", "NON CONFIGURÉE", false, Modifier.weight(1f))
        }

        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Soon("CONVERSATION", "Phase 3", Modifier.weight(1f))
            Soon("AUTOMATISATIONS", "Phase 6", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Soon("MÉMOIRE", "Phase 8", Modifier.weight(1f))
            Soon("PARAMÈTRES", "Phase 11", Modifier.weight(1f))
        }

        Spacer(Modifier.height(18.dp))
        OutlinedButton(
            onClick = vm::cycleDemo,
            border = BorderStroke(1.dp, Cyan),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) { Text("DÉMO DES ÉTATS (test visuel)", fontFamily = Mono, fontSize = 13.sp) }

        Spacer(Modifier.height(12.dp))
        Text(
            "Phase 2 : interface. Les cases grisées seront actives dans la phase indiquée.",
            color = Color.Gray, fontFamily = Mono, fontSize = 11.sp, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun Chip(
    title: String,
    value: String,
    ok: Boolean,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val color = if (ok) Cyan else Color(0xFFFF6E40)
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .background(Color(0x1A00E5FF), shape)
            .border(1.dp, color.copy(alpha = 0.5f), shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = Color.Gray, fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = color, fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Case volontairement inactive : elle indique la phase où la fonction sera construite. */
@Composable
private fun Soon(title: String, phase: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .border(1.dp, Color(0x3300E5FF), shape)
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = Color(0x8800E5FF), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp)
            Text(phase, color = Color.DarkGray, fontFamily = Mono, fontSize = 10.sp)
        }
    }
}
