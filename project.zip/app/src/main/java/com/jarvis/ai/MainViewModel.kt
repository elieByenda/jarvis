package com.jarvis.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.core.JarvisState
import com.jarvis.ai.system.Battery
import com.jarvis.ai.system.networkFlow
import com.jarvis.ai.system.readBattery
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(private val app: Application) : AndroidViewModel(app) {

    data class Ui(
        val online: Boolean = true,
        val battery: Battery = Battery(-1, false),
        val demo: JarvisState? = null
    )

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            networkFlow(app).collect { online -> _ui.update { it.copy(online = online) } }
        }
        viewModelScope.launch {
            while (isActive) {
                val b = readBattery(app)
                _ui.update { it.copy(battery = b) }
                delay(15_000)
            }
        }
    }

    /** Bouton de test visuel : fait défiler les 7 états, puis revient à l'état réel. */
    fun cycleDemo() {
        _ui.update { cur ->
            val all = JarvisState.values()
            val idx = cur.demo?.let { all.indexOf(it) } ?: -1
            val next = if (idx + 1 >= all.size) null else all[idx + 1]
            cur.copy(demo = next)
        }
    }
}
