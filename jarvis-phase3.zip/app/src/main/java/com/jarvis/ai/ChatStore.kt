package com.jarvis.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Garde les discussions sur le téléphone, dans l'espace privé de l'appli. */
class ChatStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("jarvis_private", Context.MODE_PRIVATE)

    fun load(): List<Chat> {
        val raw = prefs.getString("chats", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ms = o.getJSONArray("m")
                Chat(
                    o.getString("id"),
                    o.getString("t"),
                    (0 until ms.length()).map { j ->
                        val m = ms.getJSONObject(j)
                        Msg(m.getBoolean("u"), m.getString("x"))
                    }
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(chats: List<Chat>) {
        val arr = JSONArray()
        chats.take(50).forEach { c ->
            val ms = JSONArray()
            c.messages.takeLast(100).forEach { m ->
                ms.put(JSONObject().put("u", m.fromUser).put("x", m.text))
            }
            arr.put(JSONObject().put("id", c.id).put("t", c.title).put("m", ms))
        }
        prefs.edit().putString("chats", arr.toString()).apply()
    }
}
