package com.jarvis.ai.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.jarvis.ai.core.JarvisState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Noyau holographique. L'apparence dépend uniquement de [state].
 * Les ondes sont pour l'instant animées en continu ; en Phase 3 elles
 * seront pilotées par le niveau sonore réel du microphone.
 */
@Composable
fun HoloCore(state: JarvisState, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "core")
    val spin by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(state.spinMs, easing = LinearEasing)),
        label = "spin"
    )
    val pulse by t.animateFloat(
        0.94f, 1.06f,
        infiniteRepeatable(tween(state.pulseMs, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val wave by t.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "wave"
    )
    val col by animateColorAsState(state.color, tween(500), label = "col")

    Canvas(modifier.aspectRatio(1f)) {
        val c = center
        val r = size.minDimension / 2f

        // Halo
        drawCircle(
            brush = Brush.radialGradient(listOf(col.copy(alpha = 0.38f), Color.Transparent), center = c, radius = r),
            radius = r,
            center = c
        )

        // Anneau extérieur en pointillés
        rotate(spin, c) {
            drawCircle(
                color = col.copy(alpha = 0.85f),
                radius = r * 0.96f,
                center = c,
                style = Stroke(width = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(r * 0.16f, r * 0.05f)))
            )
        }

        // Anneau de graduations
        rotate(-spin * 0.4f, c) {
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0)
                val len = if (i % 5 == 0) r * 0.05f else r * 0.025f
                val r1 = r * 0.84f
                val r2 = r1 - len
                drawLine(
                    color = col.copy(alpha = 0.6f),
                    start = Offset(c.x + cos(a).toFloat() * r1, c.y + sin(a).toFloat() * r1),
                    end = Offset(c.x + cos(a).toFloat() * r2, c.y + sin(a).toFloat() * r2),
                    strokeWidth = 1.5f
                )
            }
        }

        // Trois arcs lumineux
        val rr = r * 0.72f
        rotate(spin * 1.6f, c) {
            for (k in 0 until 3) {
                drawArc(
                    color = col,
                    startAngle = k * 120f,
                    sweepAngle = 70f,
                    useCenter = false,
                    topLeft = Offset(c.x - rr, c.y - rr),
                    size = Size(rr * 2, rr * 2),
                    style = Stroke(width = 5f, cap = StrokeCap.Round)
                )
            }
        }

        // Cercle fin intérieur
        drawCircle(color = col.copy(alpha = 0.35f), radius = r * 0.55f, center = c, style = Stroke(width = 2f))

        // Ondes sonores (écoute / réponse / exécution)
        if (state.wave > 0f) {
            for (i in 0 until 56) {
                val a = Math.toRadians(i * 360.0 / 56)
                val len = r * 0.12f * state.wave * (0.35f + 0.65f * abs(sin(wave + i * 0.45f)))
                val r1 = r * 0.36f
                drawLine(
                    color = col,
                    start = Offset(c.x + cos(a).toFloat() * r1, c.y + sin(a).toFloat() * r1),
                    end = Offset(c.x + cos(a).toFloat() * (r1 + len), c.y + sin(a).toFloat() * (r1 + len)),
                    strokeWidth = 3f,
                    cap = StrokeCap.Round
                )
            }
        }

        // Particules en orbite
        for (i in 0 until 16) {
            val a = Math.toRadians((spin * (0.5 + (i % 3) * 0.3) + i * 22.5) % 360.0)
            val pr = r * (0.58f + (i % 5) * 0.07f)
            drawCircle(
                color = col.copy(alpha = 0.8f),
                radius = 2.5f + (i % 3),
                center = Offset(c.x + cos(a).toFloat() * pr, c.y + sin(a).toFloat() * pr)
            )
        }

        // Cœur
        val cr = r * 0.26f * pulse
        drawCircle(
            brush = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f), col, Color.Transparent), center = c, radius = cr),
            radius = cr,
            center = c
        )
    }
}
