package com.jarvis.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.ai.Chat
import com.jarvis.ai.MainViewModel
import com.jarvis.ai.Msg
import com.jarvis.ai.core.JarvisState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Cyan = Color(0xFF00E5FF)
private val Mono = FontFamily.Monospace

@Composable
fun JarvisScreen(vm: MainViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var showSettings by remember { mutableStateOf(false) }

    if (showSettings) {
        BackHandler { showSettings = false }
        SettingsScreen(ui, vm) { showSettings = false }
    } else {
        HomeScreen(ui, vm) { showSettings = true }
    }
}

/* ------------------------------------------------------------------ */
/*  ACCUEIL : hologramme, heure, salutation, discussion et clavier     */
/* ------------------------------------------------------------------ */

private fun greetings(h: Int): List<String> = when {
    h < 5 -> listOf("Il se fait tard. Je veille.", "Les meilleures idées viennent la nuit.", "Je suis là. Que souhaitez-vous ?")
    h < 12 -> listOf("Bon réveil.", "Bonjour. Prêt à commencer ?", "Belle matinée devant nous.")
    h < 18 -> listOf("Bon après-midi.", "Bon retour parmi nous.", "Je suis là. Dites-moi tout.")
    else -> listOf("Bonsoir.", "Bonne soirée. Je vous écoute.", "Bon retour parmi nous.")
}

@Composable
private fun HomeScreen(ui: MainViewModel.Ui, vm: MainViewModel, onOpenSettings: () -> Unit) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val state = ui.demo ?: when {
        !ui.online -> JarvisState.HORS_LIGNE
        ui.exec -> JarvisState.EXECUTION
        ui.busy -> JarvisState.ANALYSE
        else -> JarvisState.VEILLE
    }

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var greetIdx by remember { mutableStateOf((0..2).random()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            greetIdx += 1
        }
    }
    val date = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.FRENCH))
        .replaceFirstChar { it.uppercase() }
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"))
    val phrases = greetings(now.hour)
    val greeting = phrases[greetIdx % phrases.size]
    val hasMsgs = ui.messages.isNotEmpty()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xFF03101A)) {
                DrawerContent(
                    ui = ui,
                    onNew = {
                        vm.newChat()
                        scope.launch { drawerState.close() }
                    },
                    onOpen = { id ->
                        vm.openChat(id)
                        scope.launch { drawerState.close() }
                    },
                    onDelete = { id -> vm.deleteChat(id) },
                    onSettings = {
                        scope.launch { drawerState.close() }
                        onOpenSettings()
                    }
                )
            }
        }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            TopBar(
                onMenu = { scope.launch { drawerState.open() } },
                onNew = { vm.newChat() }
            )

            if (!hasMsgs) {
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(8.dp))
                    Text(time, color = Color.White, fontFamily = Mono, fontSize = 34.sp, fontWeight = FontWeight.Light)
                    Text(date, color = Cyan.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    HoloCore(state, Modifier.fillMaxWidth(0.8f))
                    Spacer(Modifier.height(8.dp))
                    Text(state.label, color = state.color, fontFamily = Mono, fontSize = 20.sp, letterSpacing = 5.sp)
                    if (ui.demo != null) {
                        Text("démo visuelle en cours", color = Color.Gray, fontFamily = Mono, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        greeting,
                        color = Color.White.copy(alpha = 0.85f),
                        fontFamily = Mono,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HoloCore(state, Modifier.width(64.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(state.label, color = state.color, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 3.sp)
                        Text(time, color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
                    }
                }
                val listState = rememberLazyListState()
                val last = ui.messages.size + (if (ui.busy) 1 else 0) - 1
                LaunchedEffect(ui.messages.size, ui.busy, ui.currentId) {
                    if (last >= 0) listState.animateScrollToItem(last)
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(ui.messages) { m -> Bubble(m) }
                    if (ui.busy) {
                        item {
                            Text("… en cours", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (ui.note.isNotEmpty()) {
                Text(
                    ui.note,
                    color = if (ui.aiOk == false) Color(0xFFFF6E40) else Cyan,
                    fontFamily = Mono,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
            InputBar(busy = ui.busy, onSend = vm::send)
        }
    }
}

@Composable
private fun TopBar(onMenu: () -> Unit, onNew: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBox(onMenu) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                drawLine(color = Cyan, start = Offset(0f, h * 0.22f), end = Offset(w, h * 0.22f), strokeWidth = 3f, cap = StrokeCap.Round)
                drawLine(color = Cyan, start = Offset(0f, h * 0.50f), end = Offset(w, h * 0.50f), strokeWidth = 3f, cap = StrokeCap.Round)
                drawLine(color = Cyan, start = Offset(0f, h * 0.78f), end = Offset(w * 0.6f, h * 0.78f), strokeWidth = 3f, cap = StrokeCap.Round)
            }
        }
        Text(
            "J.A.R.V.I.S.",
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            color = Cyan,
            fontFamily = Mono,
            fontSize = 14.sp,
            letterSpacing = 6.sp
        )
        IconBox(onNew) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                drawRoundRect(
                    color = Cyan,
                    topLeft = Offset(0f, 0f),
                    size = Size(w, h),
                    cornerRadius = CornerRadius(6f, 6f),
                    style = Stroke(width = 2.5f)
                )
                drawLine(color = Cyan, start = Offset(w * 0.5f, h * 0.28f), end = Offset(w * 0.5f, h * 0.72f), strokeWidth = 3f, cap = StrokeCap.Round)
                drawLine(color = Cyan, start = Offset(w * 0.28f, h * 0.5f), end = Offset(w * 0.72f, h * 0.5f), strokeWidth = 3f, cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
private fun IconBox(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun Bubble(m: Msg) {
    val me = m.fromUser
    val shape = RoundedCornerShape(14.dp)
    Box(Modifier.fillMaxWidth(), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
        Text(
            m.text,
            color = if (me) Color.White else Cyan,
            fontFamily = Mono,
            fontSize = 14.sp,
            modifier = Modifier
                .widthIn(max = 320.dp)
                .background(if (me) Color(0x2200E5FF) else Color.Transparent, shape)
                .border(1.dp, Cyan.copy(alpha = if (me) 0.5f else 0.2f), shape)
                .padding(12.dp)
        )
    }
}

@Composable
private fun InputBar(busy: Boolean, onSend: (String) -> Unit) {
    var msg by remember { mutableStateOf("") }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        focusedBorderColor = Cyan,
        unfocusedBorderColor = Cyan.copy(alpha = 0.4f),
        cursorColor = Cyan
    )
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = msg,
            onValueChange = { msg = it },
            placeholder = { Text("Écris à JARVIS…", color = Color.Gray, fontFamily = Mono, fontSize = 13.sp) },
            shape = RoundedCornerShape(26.dp),
            colors = fieldColors,
            maxLines = 4,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(if (busy) Cyan.copy(alpha = 0.3f) else Cyan)
                .clickable(enabled = !busy) {
                    if (msg.isNotBlank()) {
                        onSend(msg)
                        msg = ""
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                drawLine(color = Color.Black, start = Offset(w / 2, h * 0.88f), end = Offset(w / 2, h * 0.14f), strokeWidth = 5f, cap = StrokeCap.Round)
                drawLine(color = Color.Black, start = Offset(w / 2, h * 0.14f), end = Offset(w * 0.2f, h * 0.46f), strokeWidth = 5f, cap = StrokeCap.Round)
                drawLine(color = Color.Black, start = Offset(w / 2, h * 0.14f), end = Offset(w * 0.8f, h * 0.46f), strokeWidth = 5f, cap = StrokeCap.Round)
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  MENU ☰ : discussions + accès aux paramètres                         */
/* ------------------------------------------------------------------ */

@Composable
private fun DrawerContent(
    ui: MainViewModel.Ui,
    onNew: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit,
    onSettings: () -> Unit
) {
    Column(
        Modifier
            .fillMaxHeight()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Text("J.A.R.V.I.S.", color = Cyan, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 6.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            "＋  Nouvelle discussion",
            color = Color.White, fontFamily = Mono, fontSize = 14.sp,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onNew)
                .padding(vertical = 12.dp, horizontal = 8.dp)
        )
        Spacer(Modifier.height(10.dp))
        Text("DISCUSSIONS", color = Color.Gray, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        if (ui.chats.isEmpty()) {
            Text("Aucune discussion pour l’instant.", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
        }
        LazyColumn(Modifier.weight(1f)) {
            items(ui.chats, key = { it.id }) { c -> ChatRow(c, c.id == ui.currentId, onOpen, onDelete) }
        }
        Text(
            "Paramètres  ›",
            color = Color.White, fontFamily = Mono, fontSize = 14.sp,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onSettings)
                .padding(vertical = 14.dp, horizontal = 8.dp)
        )
    }
}

@Composable
private fun ChatRow(c: Chat, current: Boolean, onOpen: (String) -> Unit, onDelete: (String) -> Unit) {
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(armed) {
        if (armed) {
            delay(3000)
            armed = false
        }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            c.title,
            color = if (current) Cyan else Color.White,
            fontFamily = Mono,
            fontSize = 13.sp,
            maxLines = 1,
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .clickable { onOpen(c.id) }
                .padding(vertical = 12.dp, horizontal = 8.dp)
        )
        Text(
            if (armed) "Sûr ?" else "✕",
            color = Color.Gray,
            fontFamily = Mono,
            fontSize = 13.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable {
                    if (armed) {
                        onDelete(c.id)
                    } else {
                        armed = true
                    }
                }
                .padding(12.dp)
        )
    }
}

/* ------------------------------------------------------------------ */
/*  PARAMÈTRES : état, IA, automatisations, mémoire, affichage          */
/* ------------------------------------------------------------------ */

@Composable
private fun SettingsScreen(ui: MainViewModel.Ui, vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var micOk by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }
    var keyText by remember { mutableStateOf("") }
    var editKey by remember { mutableStateOf(false) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        focusedBorderColor = Cyan,
        unfocusedBorderColor = Cyan.copy(alpha = 0.4f),
        cursorColor = Cyan
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "‹  RETOUR",
                color = Cyan, fontFamily = Mono, fontSize = 13.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onBack)
                    .padding(vertical = 10.dp, horizontal = 6.dp)
            )
            Spacer(Modifier.weight(1f))
            Text("PARAMÈTRES", color = Color.White, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 4.sp)
        }
        Spacer(Modifier.height(14.dp))

        Section("ÉTAT") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip("RÉSEAU", if (ui.online) "EN LIGNE" else "HORS LIGNE", ui.online, Modifier.weight(1f))
                val b = ui.battery
                val battery = if (b.percent < 0) "N/D" else "${b.percent} %" + if (b.charging) " · charge" else ""
                Chip("BATTERIE", battery, b.percent < 0 || b.percent > 15, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip(
                    "MICRO",
                    if (micOk) "AUTORISÉ · inactif" else "TOUCHER POUR AUTORISER",
                    micOk,
                    Modifier.weight(1f)
                ) { if (!micOk) launcher.launch(Manifest.permission.RECORD_AUDIO) }
                val (iaText, iaOk) = when {
                    !ui.hasKey -> "NON CONFIGURÉE" to false
                    ui.aiOk == true -> "CONNECTÉE" to true
                    ui.aiOk == false -> "ERREUR" to false
                    else -> "CLÉ ENREGISTRÉE" to true
                }
                Chip("IA", iaText, iaOk, Modifier.weight(1f))
            }
        }

        Section("INTELLIGENCE ARTIFICIELLE") {
            Text(
                "Fournisseur : Gemini (offre gratuite de Google AI Studio). Claude n’est pas branché : son API est payante.",
                color = Color.Gray, fontFamily = Mono, fontSize = 12.sp
            )
            Spacer(Modifier.height(10.dp))
            if (!ui.hasKey || editKey) {
                Text("Colle ta clé (elle reste sur ce téléphone) :", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = keyText,
                    onValueChange = { keyText = it },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        vm.saveKey(keyText)
                        keyText = ""
                        editKey = false
                    },
                    border = BorderStroke(1.dp, Cyan),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ENREGISTRER LA CLÉ", fontFamily = Mono, fontSize = 13.sp) }
            } else {
                Text("Clé enregistrée.", color = Cyan, fontFamily = Mono, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Changer la clé",
                    color = Color.Gray, fontFamily = Mono, fontSize = 12.sp,
                    modifier = Modifier.clickable { editKey = true }
                )
            }
            if (ui.note.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    ui.note,
                    color = if (ui.aiOk == false) Color(0xFFFF6E40) else Cyan,
                    fontFamily = Mono, fontSize = 12.sp
                )
            }
        }

        Section("AUTOMATISATIONS · ACTIVES") {
            Text(
                "Écris ou dis ces commandes dans la discussion. Ce que JARVIS a vraiment fait est toujours indiqué dans sa réponse.",
                color = Color.Gray, fontFamily = Mono, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            listOf(
                "« Ouvre WhatsApp » : lance une application installée",
                "« Ouvre YouTube et recherche des tutoriels Android »",
                "« Cherche … sur Google »",
                "« Mets une alarme à 7h30 » (l’horloge s’ouvre, tu confirmes)",
                "« Minuteur de 5 minutes » (l’horloge s’ouvre)",
                "« Ouvre les paramètres Wi-Fi » (ou Bluetooth, batterie, son…)",
                "« Itinéraire vers … » : ouvre les cartes",
                "« Appelle 0812345678 » : ouvre le clavier, sans appeler",
                "« Va sur exemple.com » : ouvre le navigateur"
            ).forEach {
                Text("•  $it", color = Color.White, fontFamily = Mono, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Pas encore : routines (applications de travail), contacts, contrôle à l’intérieur d’autres applications.",
                color = Color.Gray, fontFamily = Mono, fontSize = 11.sp
            )
        }

        Section("MÉMOIRE") {
            Soon("MÉMOIRE", "Phase 8")
        }

        Section("AFFICHAGE") {
            OutlinedButton(
                onClick = vm::cycleDemo,
                border = BorderStroke(1.dp, Cyan),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) { Text("DÉMO DES ÉTATS (test visuel)", fontFamily = Mono, fontSize = 13.sp) }
            if (ui.demo != null) {
                Spacer(Modifier.height(6.dp))
                Text("État affiché : ${ui.demo.label}", color = ui.demo.color, fontFamily = Mono, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp)
            .border(1.dp, Cyan.copy(alpha = 0.3f), shape)
            .padding(12.dp)
    ) {
        Text(title, color = Cyan, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun Chip(
    title: String,
    value: String,
    ok: Boolean,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val color = if (ok) Cyan else Color(0xFFFF6E40)
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .background(Color(0x1A00E5FF), shape)
            .border(1.dp, color.copy(alpha = 0.5f), shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = Color.Gray, fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = color, fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Case volontairement inactive : elle indique la phase où la fonction sera construite. */
@Composable
private fun Soon(title: String, phase: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .border(1.dp, Color(0x3300E5FF), shape)
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = Color(0x8800E5FF), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp)
            Text(phase, color = Color.DarkGray, fontFamily = Mono, fontSize = 10.sp)
        }
    }
}
