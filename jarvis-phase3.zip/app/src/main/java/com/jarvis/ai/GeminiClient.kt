package com.jarvis.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Appelle Gemini directement avec la clé de l'utilisateur (palier gratuit de Google AI Studio). */
object GeminiClient {
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

    private const val CONSIGNE =
        "Tu es J.A.R.V.I.S., un assistant personnel calme et efficace. " +
            "Réponds en français, de façon courte et claire."

    /** history : liste de (vient de l'utilisateur ?, texte). Doit se terminer par un message de l'utilisateur. */
    suspend fun ask(key: String, history: List<Pair<Boolean, String>>): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val contents = JSONArray()
                history.forEach { (fromUser, text) ->
                    contents.put(
                        JSONObject()
                            .put("role", if (fromUser) "user" else "model")
                            .put("parts", JSONArray().put(JSONObject().put("text", text)))
                    )
                }
                val body = JSONObject()
                    .put("contents", contents)
                    .put(
                        "systemInstruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", CONSIGNE)))
                    )

                val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 45_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", key)
                }
                try {
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    if (code !in 200..299) throw IllegalStateException(friendly(code))
                    parse(raw)
                } finally {
                    conn.disconnect()
                }
            }.recoverCatching { e ->
                if (e is IllegalStateException) throw e
                throw IllegalStateException("Impossible de joindre Google. Vérifie ta connexion.")
            }
        }

    private fun parse(raw: String): String {
        val parts = JSONObject(raw)
            .optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IllegalStateException("Réponse vide de l'IA. Réessaie.")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text", "") ?: "")
        val out = sb.toString().trim()
        if (out.isEmpty()) throw IllegalStateException("Réponse vide de l'IA. Réessaie.")
        return out
    }

    private fun friendly(code: Int): String = when (code) {
        400, 401, 403 -> "Clé refusée par Google. Vérifie qu'elle est copiée en entier."
        429 -> "Limite gratuite atteinte. Attends une minute et réessaie."
        in 500..599 -> "Google a un problème pour l'instant. Réessaie plus tard."
        else -> "Erreur inattendue (code $code)."
    }
}
