package com.jarvis.ai

import android.content.Context

/** Garde la clé sur le téléphone, dans l'espace privé de l'appli. */
class KeyStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("jarvis_private", Context.MODE_PRIVATE)

    var key: String
        get() = prefs.getString("gemini_key", "") ?: ""
        set(value) {
            prefs.edit().putString("gemini_key", value.trim()).apply()
        }
}
