package com.jarvis.ai

data class Msg(val fromUser: Boolean, val text: String)

data class Chat(val id: String, val title: String, val messages: List<Msg>)
