package com.jarvis.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.automation.Automation
import com.jarvis.ai.core.JarvisState
import com.jarvis.ai.system.Battery
import com.jarvis.ai.system.networkFlow
import com.jarvis.ai.system.readBattery
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(private val app: Application) : AndroidViewModel(app) {

    data class Ui(
        val online: Boolean = true,
        val battery: Battery = Battery(-1, false),
        val demo: JarvisState? = null,
        val hasKey: Boolean = false,
        /** null = pas encore testée, true = a répondu, false = a échoué */
        val aiOk: Boolean? = null,
        val busy: Boolean = false,
        /** true pendant l'exécution d'une commande (ouvrir une appli, etc.) */
        val exec: Boolean = false,
        val chats: List<Chat> = emptyList(),
        val currentId: String? = null,
        val note: String = ""
    ) {
        val messages: List<Msg>
            get() = chats.firstOrNull { it.id == currentId }?.messages ?: emptyList()
    }

    private val store = KeyStore(app)
    private val chatStore = ChatStore(app)
    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    init {
        _ui.update { it.copy(hasKey = store.key.isNotBlank(), chats = chatStore.load()) }
        viewModelScope.launch {
            networkFlow(app).collect { online -> _ui.update { it.copy(online = online) } }
        }
        viewModelScope.launch {
            while (isActive) {
                val b = readBattery(app)
                _ui.update { it.copy(battery = b) }
                delay(15_000)
            }
        }
    }

    private fun persist() {
        chatStore.save(_ui.value.chats)
    }

    private fun appendMsg(chatId: String, m: Msg) {
        _ui.update { u ->
            u.copy(chats = u.chats.map { if (it.id == chatId) it.copy(messages = it.messages + m) else it })
        }
        persist()
    }

    fun saveKey(k: String) {
        store.key = k
        val has = store.key.isNotBlank()
        _ui.update {
            it.copy(
                hasKey = has,
                aiOk = null,
                note = if (has) "Clé enregistrée. Retourne à l’accueil et écris un message pour tester." else "Aucune clé saisie."
            )
        }
    }

    fun newChat() {
        _ui.update { it.copy(currentId = null, note = "") }
    }

    fun openChat(id: String) {
        _ui.update { it.copy(currentId = id, note = "") }
    }

    fun deleteChat(id: String) {
        _ui.update { u ->
            u.copy(
                chats = u.chats.filter { it.id != id },
                currentId = if (u.currentId == id) null else u.currentId
            )
        }
        persist()
    }

    fun send(text: String) {
        val t = text.trim()
        val cur = _ui.value
        if (t.isEmpty() || cur.busy) return

        val existing = cur.currentId?.takeIf { cid -> cur.chats.any { it.id == cid } }
        val chatId: String = existing ?: UUID.randomUUID().toString().also { newId ->
            _ui.update { it.copy(chats = listOf(Chat(newId, t.take(40), emptyList())) + it.chats, currentId = newId) }
        }
        appendMsg(chatId, Msg(true, t))
        _ui.update { it.copy(busy = true, note = "") }

        viewModelScope.launch {
            // 1) Commande locale ? (ouvrir une appli, alarme, recherche…)
            val auto = Automation.tryHandle(app, t)
            if (auto != null) {
                _ui.update { it.copy(exec = true) }
                appendMsg(chatId, Msg(false, auto.message))
                delay(1200)
                _ui.update { it.copy(exec = false, busy = false) }
                return@launch
            }
            // 2) Sinon, l'IA répond
            if (store.key.isBlank()) {
                _ui.update { it.copy(busy = false, note = "Aucune clé IA : ouvre le menu (☰), puis Paramètres, pour la saisir.") }
                return@launch
            }
            val history = _ui.value.chats.firstOrNull { it.id == chatId }?.messages ?: emptyList()
            val payload = history.takeLast(20).dropWhile { !it.fromUser }.map { it.fromUser to it.text }
            GeminiClient.ask(store.key, payload)
                .onSuccess { answer ->
                    appendMsg(chatId, Msg(false, answer))
                    _ui.update { it.copy(busy = false, aiOk = true, note = "") }
                }
                .onFailure { e ->
                    _ui.update { it.copy(busy = false, aiOk = false, note = e.message ?: "Erreur inconnue.") }
                }
        }
    }

    /** Bouton de test visuel : fait défiler les 7 états, puis revient à l'état réel. */
    fun cycleDemo() {
        _ui.update { cur ->
            val all = JarvisState.values()
            val idx = cur.demo?.let { all.indexOf(it) } ?: -1
            val next = if (idx + 1 >= all.size) null else all[idx + 1]
            cur.copy(demo = next)
        }
    }
}
