package com.jarvis.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.core.JarvisState
import com.jarvis.ai.system.Battery
import com.jarvis.ai.system.networkFlow
import com.jarvis.ai.system.readBattery
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(private val app: Application) : AndroidViewModel(app) {

    data class Msg(val fromUser: Boolean, val text: String)

    data class Ui(
        val online: Boolean = true,
        val battery: Battery = Battery(-1, false),
        val demo: JarvisState? = null,
        val hasKey: Boolean = false,
        /** null = pas encore testée, true = a répondu, false = a échoué */
        val aiOk: Boolean? = null,
        val busy: Boolean = false,
        val messages: List<Msg> = emptyList(),
        val note: String = ""
    )

    private val store = KeyStore(app)
    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    init {
        _ui.update { it.copy(hasKey = store.key.isNotBlank()) }
        viewModelScope.launch {
            networkFlow(app).collect { online -> _ui.update { it.copy(online = online) } }
        }
        viewModelScope.launch {
            while (isActive) {
                val b = readBattery(app)
                _ui.update { it.copy(battery = b) }
                delay(15_000)
            }
        }
    }

    fun saveKey(k: String) {
        store.key = k
        val has = store.key.isNotBlank()
        _ui.update {
            it.copy(
                hasKey = has,
                aiOk = null,
                note = if (has) "Clé enregistrée. Écris un message pour tester." else "Aucune clé saisie."
            )
        }
    }

    fun send(text: String) {
        val t = text.trim()
        val cur = _ui.value
        if (t.isEmpty() || cur.busy) return
        if (store.key.isBlank()) {
            _ui.update { it.copy(note = "Colle d'abord ta clé.") }
            return
        }
        val history = cur.messages + Msg(true, t)
        _ui.update { it.copy(messages = history, busy = true, note = "") }
        viewModelScope.launch {
            val payload = history.takeLast(20).dropWhile { !it.fromUser }.map { it.fromUser to it.text }
            GeminiClient.ask(store.key, payload)
                .onSuccess { answer ->
                    _ui.update {
                        it.copy(messages = it.messages + Msg(false, answer), busy = false, aiOk = true, note = "")
                    }
                }
                .onFailure { e ->
                    _ui.update { it.copy(busy = false, aiOk = false, note = e.message ?: "Erreur inconnue.") }
                }
        }
    }

    /** Bouton de test visuel : fait défiler les 7 états, puis revient à l'état réel. */
    fun cycleDemo() {
        _ui.update { cur ->
            val all = JarvisState.values()
            val idx = cur.demo?.let { all.indexOf(it) } ?: -1
            val next = if (idx + 1 >= all.size) null else all[idx + 1]
            cur.copy(demo = next)
        }
    }
}
