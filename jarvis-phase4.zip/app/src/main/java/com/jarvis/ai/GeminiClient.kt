package com.jarvis.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Appelle Gemini directement avec la clé de l'utilisateur (palier gratuit de Google AI Studio). */
object GeminiClient {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private const val DEFAULT_MODEL = "gemini-flash-latest"
    private val EXCLUDE = listOf(
        "image", "tts", "audio", "live", "native", "robotics", "computer",
        "embedding", "exp", "vision", "aqa", "imagen", "veo", "learnlm", "gemma", "thinking"
    )

    @Volatile
    private var cachedModels: List<String>? = null

    private class ApiError(val code: Int, msg: String) : Exception(msg)

    private fun consigne(): String =
        "Tu es J.A.R.V.I.S., un assistant personnel calme, intelligent et efficace. " +
            "Réponds en français, de façon courte et claire. " +
            "Honnêteté : ne prétends jamais avoir ouvert une application, envoyé un message ou effectué une action : " +
            "ces actions sont gérées par des commandes locales de l'application (par exemple « ouvre WhatsApp »), pas par toi. " +
            "Si on te demande une action que tu ne peux pas faire, dis-le simplement. " +
            "Date et heure : " + java.time.LocalDateTime.now().toString() + "."

    /** history : liste de (vient de l'utilisateur ?, texte). Doit se terminer par un message de l'utilisateur. */
    suspend fun ask(key: String, history: List<Pair<Boolean, String>>): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching { askWithFallback(key, history) }
                .recoverCatching { e ->
                    if (e is IllegalStateException) throw e
                    throw IllegalStateException(
                        "Impossible de joindre Google. Vérifie ta connexion. (${e.javaClass.simpleName})"
                    )
                }
        }

    /** Essaie le modèle par défaut, puis d'autres modèles « flash » disponibles pour cette clé. */
    private fun askWithFallback(key: String, history: List<Pair<Boolean, String>>): String {
        val models = (listOf(DEFAULT_MODEL) + listModels(key)).distinct().take(4)
        var last: ApiError? = null
        val tried = mutableListOf<String>()
        for (m in models) {
            tried += m
            try {
                return callModel(key, m, history)
            } catch (e: ApiError) {
                last = e
                val keyProblem = e.code == 401 || e.code == 403 ||
                    (e.code == 400 && e.message.orEmpty().contains("API key", ignoreCase = true))
                if (keyProblem) break
            }
        }
        val err = last ?: throw IllegalStateException("Aucune réponse de Google. Réessaie.")
        val detail = (err.message ?: "").take(200)
        val hint = when (err.code) {
            400, 401, 403 -> "Clé refusée par Google. Vérifie qu'elle est copiée en entier. "
            429 -> "Limite gratuite atteinte. Attends une minute. "
            else -> ""
        }
        throw IllegalStateException("${hint}Google (code ${err.code}, ${tried.joinToString(", ")}) : $detail")
    }

    private fun callModel(key: String, model: String, history: List<Pair<Boolean, String>>): String {
        val contents = JSONArray()
        history.forEach { (fromUser, text) ->
            contents.put(
                JSONObject()
                    .put("role", if (fromUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("contents", contents)
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", consigne())))
            )

        val conn = (URL("$BASE/models/$model:generateContent").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiError(code, errorText(raw).ifBlank { "pas de détail" })
            return parse(raw)
        } finally {
            conn.disconnect()
        }
    }

    /** Liste les modèles « flash » utilisables avec cette clé (stables d'abord, les plus récents d'abord). */
    private fun listModels(key: String): List<String> {
        cachedModels?.let { return it }
        return try {
            val conn = (URL("$BASE/models?pageSize=200").openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                setRequestProperty("x-goog-api-key", key)
            }
            try {
                if (conn.responseCode !in 200..299) return emptyList()
                val raw = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONObject(raw).optJSONArray("models") ?: return emptyList()
                val names = (0 until arr.length()).mapNotNull { i ->
                    val o = arr.optJSONObject(i) ?: return@mapNotNull null
                    val name = o.optString("name").removePrefix("models/")
                    val methods = o.optJSONArray("supportedGenerationMethods")
                    val ok = methods != null && (0 until methods.length()).any { methods.optString(it) == "generateContent" }
                    if (ok && name.startsWith("gemini") && name.contains("flash") && EXCLUDE.none { name.contains(it) }) name else null
                }
                val sorted = names.sortedWith(
                    compareBy<String>({ it.contains("preview") }, { it.contains("lite") }).thenByDescending { it }
                )
                if (sorted.isNotEmpty()) cachedModels = sorted
                sorted
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun errorText(raw: String): String = try {
        JSONObject(raw).optJSONObject("error")?.optString("message", "") ?: ""
    } catch (e: Exception) {
        ""
    }

    private fun parse(raw: String): String {
        val parts = JSONObject(raw)
            .optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IllegalStateException("Réponse vide de l'IA. Réessaie.")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text", "") ?: "")
        val out = sb.toString().trim()
        if (out.isEmpty()) throw IllegalStateException("Réponse vide de l'IA. Réessaie.")
        return out
    }
}
