package com.jarvis.ai.core

import androidx.compose.ui.graphics.Color

/** Les 7 états du noyau holographique. Chaque état change couleur, vitesse et ondes. */
enum class JarvisState(
    val label: String,
    val color: Color,
    val spinMs: Int,
    val pulseMs: Int,
    val wave: Float
) {
    VEILLE("VEILLE", Color(0xFFB5603F), 26000, 3600, 0f),
    ECOUTE("ÉCOUTE", Color(0xFFD97757), 9000, 900, 1f),
    ANALYSE("ANALYSE", Color(0xFFF0B48F), 2600, 1400, 0.25f),
    REPONSE("RÉPONSE", Color(0xFFFFB38A), 12000, 650, 0.8f),
    EXECUTION("EXÉCUTION", Color(0xFF00E676), 5000, 1000, 0.4f),
    ERREUR("ERREUR", Color(0xFFFF5252), 8000, 500, 0f),
    HORS_LIGNE("HORS LIGNE", Color(0xFF8A7D75), 42000, 5200, 0f)
}
