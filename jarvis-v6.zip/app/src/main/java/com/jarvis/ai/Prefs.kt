package com.jarvis.ai

import android.content.Context
import org.json.JSONArray

/** Réglages de l'appli, gardés sur le téléphone. */
class AppSettings(ctx: Context) {
    private val p = ctx.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    var autoRead: Boolean
        get() = p.getBoolean("auto_read", false)
        set(v) {
            p.edit().putBoolean("auto_read", v).apply()
        }

    var speed: Float
        get() = p.getFloat("speed", 1.0f)
        set(v) {
            p.edit().putFloat("speed", v).apply()
        }

    var memoryOn: Boolean
        get() = p.getBoolean("memory_on", true)
        set(v) {
            p.edit().putBoolean("memory_on", v).apply()
        }
}

/** Souvenirs que l'utilisateur a demandé de retenir. Ils restent sur le téléphone. */
class MemoryStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("jarvis_memory", Context.MODE_PRIVATE)

    fun all(): List<String> = try {
        val arr = JSONArray(p.getString("items", "[]") ?: "[]")
        (0 until arr.length()).map { arr.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(items: List<String>) {
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        p.edit().putString("items", arr.toString()).apply()
    }
}
