package com.jarvis.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.automation.Automation
import com.jarvis.ai.core.JarvisState
import com.jarvis.ai.system.Battery
import com.jarvis.ai.system.networkFlow
import com.jarvis.ai.system.readBattery
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(private val app: Application) : AndroidViewModel(app) {

    data class Ui(
        val online: Boolean = true,
        val battery: Battery = Battery(-1, false),
        val demo: JarvisState? = null,
        val hasKey: Boolean = false,
        /** null = pas encore testée, true = a répondu, false = a échoué */
        val aiOk: Boolean? = null,
        val busy: Boolean = false,
        /** true pendant l'exécution d'une commande (ouvrir une appli, etc.) */
        val exec: Boolean = false,
        val chats: List<Chat> = emptyList(),
        val currentId: String? = null,
        val note: String = "",
        val autoRead: Boolean = false,
        val speed: Float = 1.0f,
        val memoryOn: Boolean = true,
        val memories: List<String> = emptyList()
    ) {
        val messages: List<Msg>
            get() = chats.firstOrNull { it.id == currentId }?.messages ?: emptyList()
    }

    private val store = KeyStore(app)
    private var sendJob: Job? = null
    private val chatStore = ChatStore(app)
    private val settings = AppSettings(app)
    private val memory = MemoryStore(app)
    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    init {
        _ui.update {
            it.copy(
                hasKey = store.key.isNotBlank(),
                chats = chatStore.load(),
                autoRead = settings.autoRead,
                speed = settings.speed,
                memoryOn = settings.memoryOn,
                memories = memory.all()
            )
        }
        viewModelScope.launch {
            networkFlow(app).collect { online -> _ui.update { it.copy(online = online) } }
        }
        viewModelScope.launch {
            while (isActive) {
                val b = readBattery(app)
                _ui.update { it.copy(battery = b) }
                delay(15_000)
            }
        }
    }

    private fun persist() {
        chatStore.save(_ui.value.chats)
    }

    private fun appendMsg(chatId: String, m: Msg) {
        _ui.update { u ->
            u.copy(chats = u.chats.map { if (it.id == chatId) it.copy(messages = it.messages + m) else it })
        }
        persist()
    }

    fun saveKey(k: String) {
        store.key = k
        val has = store.key.isNotBlank()
        _ui.update {
            it.copy(
                hasKey = has,
                aiOk = null,
                note = if (has) "Clé enregistrée. Retourne à l’accueil et écris un message pour tester." else "Aucune clé saisie."
            )
        }
    }

    fun newChat() {
        _ui.update { it.copy(currentId = null, note = "") }
    }

    fun openChat(id: String) {
        _ui.update { it.copy(currentId = id, note = "") }
    }

    fun deleteChat(id: String) {
        _ui.update { u ->
            u.copy(
                chats = u.chats.filter { it.id != id },
                currentId = if (u.currentId == id) null else u.currentId
            )
        }
        persist()
    }

    fun send(text: String) {
        val t = text.trim()
        val cur = _ui.value
        if (t.isEmpty() || cur.busy) return

        val existing = cur.currentId?.takeIf { cid -> cur.chats.any { it.id == cid } }
        val chatId: String = existing ?: UUID.randomUUID().toString().also { newId ->
            _ui.update { it.copy(chats = listOf(Chat(newId, t.take(40), emptyList())) + it.chats, currentId = newId) }
        }
        appendMsg(chatId, Msg(true, t))
        _ui.update { it.copy(busy = true, note = "") }

        sendJob = viewModelScope.launch {
            // 0) Mémoire : « souviens-toi que… », « oublie tout », « que sais-tu de moi ? »
            val memReply = memoryCmd(t)
            if (memReply != null) {
                appendMsg(chatId, Msg(false, memReply))
                _ui.update { it.copy(busy = false) }
                return@launch
            }
            // 1) Commande locale ? (ouvrir une appli, alarme, recherche…)
            val auto = Automation.tryHandle(app, t)
            if (auto != null) {
                _ui.update { it.copy(exec = true) }
                appendMsg(chatId, Msg(false, auto.message))
                delay(1200)
                _ui.update { it.copy(exec = false, busy = false) }
                return@launch
            }
            // 2) Sinon, l'IA répond
            if (store.key.isBlank()) {
                _ui.update { it.copy(busy = false, note = "Aucune clé IA : ouvre le menu (☰), puis Paramètres, pour la saisir.") }
                return@launch
            }
            val history = _ui.value.chats.firstOrNull { it.id == chatId }?.messages ?: emptyList()
            val payload = history.takeLast(20).dropWhile { !it.fromUser }.map { it.fromUser to it.text }
            GeminiClient.ask(store.key, payload, if (settings.memoryOn) memory.all() else emptyList())
                .onSuccess { answer ->
                    appendMsg(chatId, Msg(false, answer))
                    _ui.update { it.copy(busy = false, aiOk = true, note = "") }
                }
                .onFailure { e ->
                    _ui.update { it.copy(busy = false, aiOk = false, note = e.message ?: "Erreur inconnue.") }
                }
        }
    }

    private fun memoryCmd(text: String): String? {
        val t = text.trim()
        val add = Regex(
            "^(?:jarvis[ ,]*)?(?:souviens[- ]toi|rappelle[- ]toi|retiens|m[ée]morise|n['’]oublie pas)\\s*(?:que|qu['’]|:)?\\s*(.+)$",
            RegexOption.IGNORE_CASE
        ).find(t)
        if (add != null) {
            val fact = add.groupValues[1].trim().trimEnd('.', '!')
            if (fact.length < 4) return null
            if (!settings.memoryOn) return "La mémoire est désactivée. Tu peux l’activer dans Paramètres."
            val list = (memory.all().filter { !it.equals(fact, ignoreCase = true) } + fact).takeLast(100)
            memory.save(list)
            _ui.update { it.copy(memories = list) }
            return "C’est noté : $fact."
        }
        val forget = Regex(
            "^(?:jarvis[ ,]*)?(?:oublie|efface)\\s+(?:tout|toute ma m[ée]moire|toute la m[ée]moire|tes souvenirs)\\s*[.!]?$",
            RegexOption.IGNORE_CASE
        )
        if (forget.containsMatchIn(t)) {
            clearMemories()
            return "J’ai tout effacé de ma mémoire."
        }
        val show = Regex(
            "que sais[- ]tu (?:de|sur) moi|qu['’]est[- ]ce que tu sais (?:de|sur) moi|montre[- ](?:moi )?ta m[ée]moire|tes souvenirs",
            RegexOption.IGNORE_CASE
        )
        if (show.containsMatchIn(t)) {
            val list = memory.all()
            return if (list.isEmpty()) "Je ne retiens rien pour l’instant. Dis « souviens-toi que… » pour m’apprendre quelque chose."
            else "Voici ce que je retiens :\n" + list.joinToString("\n") { "• $it" }
        }
        return null
    }

    fun setAutoRead(v: Boolean) {
        settings.autoRead = v
        _ui.update { it.copy(autoRead = v) }
    }

    fun setSpeed(v: Float) {
        settings.speed = v
        _ui.update { it.copy(speed = v) }
    }

    fun setMemoryOn(v: Boolean) {
        settings.memoryOn = v
        _ui.update { it.copy(memoryOn = v) }
    }

    fun deleteMemory(index: Int) {
        val list = memory.all().toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            memory.save(list)
            _ui.update { it.copy(memories = list) }
        }
    }

    fun clearMemories() {
        memory.save(emptyList())
        _ui.update { it.copy(memories = emptyList()) }
    }

    fun clearAllChats() {
        sendJob?.cancel()
        _ui.update { it.copy(chats = emptyList(), currentId = null, busy = false, exec = false, note = "") }
        persist()
    }

    /** Arrête la réflexion ou la commande en cours. */
    fun stop() {
        sendJob?.cancel()
        sendJob = null
        _ui.update { it.copy(busy = false, exec = false, note = "Arrêté.") }
    }

    /** Bouton de test visuel : fait défiler les 7 états, puis revient à l'état réel. */
    fun cycleDemo() {
        _ui.update { cur ->
            val all = JarvisState.values()
            val idx = cur.demo?.let { all.indexOf(it) } ?: -1
            val next = if (idx + 1 >= all.size) null else all[idx + 1]
            cur.copy(demo = next)
        }
    }
}
