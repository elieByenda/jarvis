package com.jarvis.ai.automation

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import java.net.URLEncoder
import java.text.Normalizer

/** Résultat d'une commande exécutée. Le message dit ce qui a RÉELLEMENT été fait. */
data class AutoResult(val message: String)

/**
 * Moteur d'automatisation : reconnaît des commandes en français et les exécute
 * avec les mécanismes officiels d'Android (Intents). Retourne null si le texte
 * n'est pas une commande : il part alors vers l'IA.
 */
object Automation {

    private val accents = Regex("\\p{InCombiningDiacriticalMarks}+")

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(accents, "")
            .replace('’', '\'')
            .replace(Regex("[^a-z0-9:'.+\\s/-]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun start(ctx: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    fun tryHandle(ctx: Context, raw: String): AutoResult? {
        var s = norm(raw)
        s = s.removePrefix("jarvis").trim()
        s = s.replace(Regex("^(s'il te plait|stp|peux tu|pourrais tu|tu peux|veux tu)\\s+"), "").trim()
        s = s.replace(Regex("\\s+(s'il te plait|stp|merci)$"), "").trim()
        if (s.isEmpty()) return null
        return settingsCmd(ctx, s)
            ?: alarmCmd(ctx, s)
            ?: timerCmd(ctx, s)
            ?: youtubeCmd(ctx, s)
            ?: webCmd(ctx, s)
            ?: mapCmd(ctx, s)
            ?: dialCmd(ctx, s)
            ?: siteCmd(ctx, s)
            ?: openAppCmd(ctx, s)
    }

    private fun settingsCmd(ctx: Context, s: String): AutoResult? {
        if (!(s.contains("parametre") || s.contains("reglage"))) return null
        if (!Regex("^(ouvre|ouvrir|lance|affiche|va dans|va sur)\\b").containsMatchIn(s)) return null
        val table = listOf(
            Triple("wifi", Settings.ACTION_WIFI_SETTINGS, "Wi-Fi"),
            Triple("wi-fi", Settings.ACTION_WIFI_SETTINGS, "Wi-Fi"),
            Triple("bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth"),
            Triple("batterie", Settings.ACTION_BATTERY_SAVER_SETTINGS, "batterie"),
            Triple("son", Settings.ACTION_SOUND_SETTINGS, "son"),
            Triple("volume", Settings.ACTION_SOUND_SETTINGS, "son"),
            Triple("affichage", Settings.ACTION_DISPLAY_SETTINGS, "affichage"),
            Triple("ecran", Settings.ACTION_DISPLAY_SETTINGS, "affichage"),
            Triple("localisation", Settings.ACTION_LOCATION_SOURCE_SETTINGS, "localisation"),
            Triple("gps", Settings.ACTION_LOCATION_SOURCE_SETTINGS, "localisation"),
            Triple("application", Settings.ACTION_APPLICATION_SETTINGS, "applications"),
            Triple("reseau", Settings.ACTION_WIRELESS_SETTINGS, "réseau"),
            Triple("accessibilite", Settings.ACTION_ACCESSIBILITY_SETTINGS, "accessibilité")
        )
        val hit = table.firstOrNull { s.contains(it.first) }
        val action = hit?.second ?: Settings.ACTION_SETTINGS
        val label = hit?.third ?: "généraux"
        val ok = start(ctx, Intent(action))
        return AutoResult(
            if (ok) "J’ai ouvert les paramètres $label."
            else "Je n’ai pas pu ouvrir les paramètres $label sur ce téléphone."
        )
    }

    private fun alarmCmd(ctx: Context, s: String): AutoResult? {
        if (!s.contains("reveil") && !s.contains("alarme")) return null
        val verb = Regex("^(mets|met|mettre|regle|regler|programme|programmer|cree|creer|ajoute|lance|active)\\b")
        if (!verb.containsMatchIn(s) && !s.startsWith("reveille")) return null
        val m = Regex("(\\d{1,2})\\s*(?:h|:|heures?)\\s*(\\d{1,2})?").find(s)
            ?: return AutoResult("Je n’ai pas compris l’heure. Dis par exemple : « mets une alarme à 7h30 ».")
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if ((s.contains("soir") || s.contains("apres midi") || s.contains("apres-midi")) && h < 12) h += 12
        if (h > 23 || min > 59) return AutoResult("Cette heure n’est pas valide.")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val ok = start(ctx, i)
        val hh = "%02d:%02d".format(h, min)
        return AutoResult(
            if (ok) "J’ai demandé à l’horloge de régler une alarme à $hh. Vérifie dans l’application Horloge qu’elle est bien activée."
            else "Je n’ai pas pu ouvrir l’application Horloge sur ce téléphone."
        )
    }

    private fun timerCmd(ctx: Context, s: String): AutoResult? {
        if (!(s.contains("minuteur") || s.contains("timer") || s.contains("compte a rebours"))) return null
        val m = Regex("(\\d+)\\s*(secondes?|sec|minutes?|min|heures?|h)\\b").find(s)
            ?: return AutoResult("Je n’ai pas compris la durée. Dis par exemple : « minuteur de 5 minutes ».")
        val n = m.groupValues[1].toInt()
        val unit = m.groupValues[2]
        val secs = when {
            unit.startsWith("h") -> n * 3600
            unit.startsWith("m") -> n * 60
            else -> n
        }
        if (secs < 1 || secs > 86_400) return AutoResult("Cette durée n’est pas valide (1 seconde à 24 heures).")
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val ok = start(ctx, i)
        return AutoResult(
            if (ok) "J’ai demandé à l’horloge de lancer un minuteur de ${m.groupValues[1]} ${m.groupValues[2]}. Vérifie dans l’application Horloge."
            else "Je n’ai pas pu ouvrir l’application Horloge sur ce téléphone."
        )
    }

    private fun youtubeCmd(ctx: Context, s: String): AutoResult? {
        if (!s.contains("youtube")) return null
        val q = Regex("(?:recherche|cherche|trouve)r?\\s+(.+?)\\s+sur\\s+youtube").find(s)?.groupValues?.get(1)
            ?: Regex("youtube.*?\\b(?:recherche|cherche|trouve)r?\\s+(.+)").find(s)?.groupValues?.get(1)
            ?: return null
        var ok = start(
            ctx,
            Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        )
        if (!ok) {
            ok = start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + enc(q))))
        }
        return AutoResult(
            if (ok) "J’ai lancé YouTube avec la recherche « $q »."
            else "Je n’ai pas pu ouvrir YouTube."
        )
    }

    private fun webCmd(ctx: Context, s: String): AutoResult? {
        val q = Regex("(?:recherche|cherche)r?\\s+(.+?)\\s+sur\\s+(?:google|internet|le web|le net)").find(s)?.groupValues?.get(1)
            ?: Regex("(?:recherche|cherche)r?\\s+sur\\s+(?:google|internet|le web|le net)\\s+(.+)").find(s)?.groupValues?.get(1)
            ?: return null
        val ok = start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + enc(q))))
        return AutoResult(
            if (ok) "J’ai ouvert la recherche Google pour « $q »."
            else "Je n’ai pas pu ouvrir le navigateur."
        )
    }

    private fun mapCmd(ctx: Context, s: String): AutoResult? {
        val q = Regex("(?:itineraire|navigue|navigation|emmene moi|conduis moi|guide moi)\\s+(?:(?:vers|au|aux|a|jusqu a|jusqu'a|pour aller a)\\s+)?(.+)")
            .find(s)?.groupValues?.get(1)
            ?: Regex("(?:cherche|trouve|montre)\\s+(.+?)\\s+sur\\s+(?:la carte|maps|google maps)").find(s)?.groupValues?.get(1)
            ?: return null
        val ok = start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + enc(q))))
        return AutoResult(
            if (ok) "J’ai ouvert la carte pour « $q »."
            else "Je n’ai pas trouvé d’application de cartes sur ce téléphone."
        )
    }

    private fun dialCmd(ctx: Context, s: String): AutoResult? {
        val num = Regex("^(?:appelle|appeler|compose|composer|telephone a)\\s+(?:le\\s+)?([+0-9][0-9 ]{4,})$")
            .find(s)?.groupValues?.get(1)?.replace(" ", "")
        if (num != null) {
            val ok = start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
            return AutoResult(
                if (ok) "J’ai ouvert le clavier téléphonique avec le numéro $num. Appuie sur « appeler » pour lancer l’appel."
                else "Je n’ai pas pu ouvrir le clavier téléphonique."
            )
        }
        if (Regex("^(appelle|appeler)\\s+\\S+(\\s+\\S+){0,2}$").containsMatchIn(s)) {
            return AutoResult("Je peux composer un numéro, mais je n’ai pas encore accès à tes contacts. Donne-moi le numéro.")
        }
        return null
    }

    private fun siteCmd(ctx: Context, s: String): AutoResult? {
        val url = Regex("^(?:va sur|ouvre le site|ouvre|ouvrir|lance)\\s+(?:le site\\s+)?((?:https?://)?[a-z0-9-]+(?:\\.[a-z0-9-]+)+(?:/\\S*)?)$")
            .find(s)?.groupValues?.get(1) ?: return null
        val full = if (url.startsWith("http")) url else "https://$url"
        val ok = start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(full)))
        return AutoResult(if (ok) "J’ai ouvert $url dans le navigateur." else "Je n’ai pas pu ouvrir $url.")
    }

    private fun openAppCmd(ctx: Context, s: String): AutoResult? {
        val rest = Regex("^(?:ouvre|ouvrir|lance|lancer|demarre|demarrer)\\s+(.+)$").find(s)?.groupValues?.get(1)
            ?: return null
        var target = rest.replace(Regex("^(?:l'application|l'appli|l'app)\\s*"), "")
        target = target.replace(Regex("^(?:l application|l appli|l app|application|appli|app|le|la|les|mon|ma|mes|l)\\s+"), "")
        target = target.replace(Regex("^l'"), "").trim()
        if (target.isEmpty()) return null
        if (target.contains("applications de travail") || target.contains("applis de travail")) {
            return AutoResult("Les routines « applications de travail » ne sont pas encore configurables. Dis-moi quelles applications tu veux, et je les ajouterai à la prochaine version.")
        }
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0).map {
            val label = it.loadLabel(pm).toString()
            Triple(norm(label), it.activityInfo.packageName, label)
        }
        val best = apps.firstOrNull { it.first == target }
            ?: apps.firstOrNull { it.first.startsWith(target) }
            ?: apps.firstOrNull { it.first.contains(target) }
            ?: apps.firstOrNull { it.first.length >= 4 && target.contains(it.first) }
        if (best == null) {
            return if (target.split(" ").size <= 3) {
                AutoResult("Je ne trouve pas d’application nommée « $target » sur ce téléphone.")
            } else {
                null
            }
        }
        val intent = pm.getLaunchIntentForPackage(best.second)
            ?: return AutoResult("Je n’ai pas pu lancer ${best.third}.")
        return AutoResult(if (start(ctx, intent)) "J’ai lancé ${best.third}." else "Je n’ai pas pu lancer ${best.third}.")
    }
}
