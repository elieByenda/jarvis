package com.jarvis.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.ai.Chat
import com.jarvis.ai.MainViewModel
import com.jarvis.ai.Msg
import com.jarvis.ai.core.JarvisState
import com.jarvis.ai.voice.Listener
import com.jarvis.ai.voice.Speaker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Ink = Color.White
private val Accent = Color(0xFFD97757)
private val Mono = FontFamily.Monospace

@Composable
fun JarvisScreen(vm: MainViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var showSettings by remember { mutableStateOf(false) }
    var showCall by remember { mutableStateOf(false) }

    if (showCall) {
        BackHandler { showCall = false }
        CallScreen(ui, vm) { showCall = false }
    } else if (showSettings) {
        BackHandler { showSettings = false }
        SettingsScreen(ui, vm) { showSettings = false }
    } else {
        HomeScreen(ui, vm, onOpenSettings = { showSettings = true }, onCall = { showCall = true })
    }
}

/* ------------------------------------------------------------------ */
/*  ACCUEIL : hologramme, heure, salutation, discussion et clavier     */
/* ------------------------------------------------------------------ */

private fun greetings(h: Int): List<String> = when {
    h < 5 -> listOf("Il se fait tard. Je veille.", "Les meilleures idées viennent la nuit.", "Je suis là. Que souhaitez-vous ?")
    h < 12 -> listOf("Bon réveil.", "Bonjour. Prêt à commencer ?", "Belle matinée devant nous.")
    h < 18 -> listOf("Bon après-midi.", "Bon retour parmi nous.", "Je suis là. Dites-moi tout.")
    else -> listOf("Bonsoir.", "Bonne soirée. Je vous écoute.", "Bon retour parmi nous.")
}

@Composable
private fun HomeScreen(ui: MainViewModel.Ui, vm: MainViewModel, onOpenSettings: () -> Unit, onCall: () -> Unit) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val uiNow by rememberUpdatedState(ui)
    val speaker = remember { Speaker(ctx) { uiNow.speed } }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }

    // Lecture automatique des nouvelles réponses (si activée dans les paramètres)
    var seenChat by remember { mutableStateOf<String?>(ui.currentId) }
    var seenCount by remember { mutableStateOf(ui.messages.size) }
    LaunchedEffect(ui.currentId, ui.messages.size) {
        if (seenChat != ui.currentId) {
            seenChat = ui.currentId
            seenCount = ui.messages.size
            return@LaunchedEffect
        }
        if (ui.messages.size > seenCount) {
            val m = ui.messages.last()
            if (!m.fromUser && ui.autoRead) speaker.speak(m.text)
        }
        seenCount = ui.messages.size
    }

    val state = ui.demo ?: when {
        !ui.online -> JarvisState.HORS_LIGNE
        ui.exec -> JarvisState.EXECUTION
        ui.busy -> JarvisState.ANALYSE
        else -> JarvisState.VEILLE
    }

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var greetIdx by remember { mutableStateOf((0..2).random()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            greetIdx += 1
        }
    }
    val date = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.FRENCH))
        .replaceFirstChar { it.uppercase() }
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"))
    val phrases = greetings(now.hour)
    val greeting = phrases[greetIdx % phrases.size]
    val hasMsgs = ui.messages.isNotEmpty()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xFF0D0D0D)) {
                DrawerContent(
                    ui = ui,
                    onNew = {
                        vm.newChat()
                        scope.launch { drawerState.close() }
                    },
                    onOpen = { id ->
                        vm.openChat(id)
                        scope.launch { drawerState.close() }
                    },
                    onDelete = { id -> vm.deleteChat(id) },
                    onSettings = {
                        scope.launch { drawerState.close() }
                        onOpenSettings()
                    }
                )
            }
        }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            TopBar(
                onMenu = { scope.launch { drawerState.open() } },
                onNew = { vm.newChat() },
                onCall = onCall
            )

            if (!hasMsgs) {
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(8.dp))
                    Text(time, color = Color.White, fontFamily = Mono, fontSize = 34.sp, fontWeight = FontWeight.Light)
                    Text(date, color = Ink.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    HoloCore(state, Modifier.fillMaxWidth(0.8f))
                    Spacer(Modifier.height(8.dp))
                    Text(state.label, color = state.color, fontFamily = Mono, fontSize = 20.sp, letterSpacing = 5.sp)
                    if (ui.demo != null) {
                        Text("démo visuelle en cours", color = Color.Gray, fontFamily = Mono, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        greeting,
                        color = Color.White.copy(alpha = 0.85f),
                        fontFamily = Mono,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HoloCore(state, Modifier.width(64.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(state.label, color = state.color, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 3.sp)
                        Text(time, color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
                    }
                }
                val listState = rememberLazyListState()
                val last = ui.messages.size + (if (ui.busy) 1 else 0) - 1
                LaunchedEffect(ui.messages.size, ui.busy, ui.currentId) {
                    if (last >= 0) listState.animateScrollToItem(last)
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(ui.messages) { m ->
                        Bubble(m, if (!m.fromUser) ({ speaker.speak(m.text) }) else null)
                    }
                    if (ui.busy) {
                        item {
                            Text("… en cours", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (ui.note.isNotEmpty()) {
                Text(
                    ui.note,
                    color = if (ui.aiOk == false) Color(0xFFFF5252) else Ink.copy(alpha = 0.7f),
                    fontFamily = Mono,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
            InputBar(
                busy = ui.busy,
                onSend = { text ->
                    speaker.stop()
                    vm.send(text)
                },
                onStop = {
                    speaker.stop()
                    vm.stop()
                }
            )
        }
    }
}

@Composable
private fun TopBar(onMenu: () -> Unit, onNew: () -> Unit, onCall: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBox(onMenu) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                drawLine(color = Ink, start = Offset(0f, h * 0.22f), end = Offset(w, h * 0.22f), strokeWidth = 3f, cap = StrokeCap.Round)
                drawLine(color = Ink, start = Offset(0f, h * 0.50f), end = Offset(w, h * 0.50f), strokeWidth = 3f, cap = StrokeCap.Round)
                drawLine(color = Ink, start = Offset(0f, h * 0.78f), end = Offset(w * 0.6f, h * 0.78f), strokeWidth = 3f, cap = StrokeCap.Round)
            }
        }
        Text(
            "J.A.R.V.I.S.",
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            color = Ink,
            fontFamily = Mono,
            fontSize = 14.sp,
            letterSpacing = 6.sp
        )
        IconBox(onCall) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                val bars = listOf(0.25f to 0.2f, 0.45f to 0.55f, 0.65f to 0.4f, 0.85f to 0.2f)
                bars.forEach { (x, half) ->
                    drawLine(
                        color = Ink,
                        start = Offset(w * x - w * 0.12f, h * (0.5f - half)),
                        end = Offset(w * x - w * 0.12f, h * (0.5f + half)),
                        strokeWidth = 4f,
                        cap = StrokeCap.Round
                    )
                }
            }
        }
        IconBox(onNew) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                drawRoundRect(
                    color = Ink,
                    topLeft = Offset(0f, 0f),
                    size = Size(w, h),
                    cornerRadius = CornerRadius(6f, 6f),
                    style = Stroke(width = 2.5f)
                )
                drawLine(color = Ink, start = Offset(w * 0.5f, h * 0.28f), end = Offset(w * 0.5f, h * 0.72f), strokeWidth = 3f, cap = StrokeCap.Round)
                drawLine(color = Ink, start = Offset(w * 0.28f, h * 0.5f), end = Offset(w * 0.72f, h * 0.5f), strokeWidth = 3f, cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
private fun IconBox(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun Bubble(m: Msg, onSpeak: (() -> Unit)?) {
    val me = m.fromUser
    val shape = RoundedCornerShape(14.dp)
    Box(Modifier.fillMaxWidth(), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(horizontalAlignment = if (me) Alignment.End else Alignment.Start) {
            Text(
                m.text,
                color = Color.White,
                fontFamily = Mono,
                fontSize = 14.sp,
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .background(if (me) Color(0x14FFFFFF) else Color.Transparent, shape)
                    .border(1.dp, Ink.copy(alpha = if (me) 0.25f else 0f), shape)
                    .padding(12.dp)
            )
            if (onSpeak != null) {
                Text(
                    "▶ Écouter",
                    color = Color.Gray,
                    fontFamily = Mono,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onSpeak)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun InputBar(busy: Boolean, onSend: (String) -> Unit, onStop: () -> Unit) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var micNote by remember { mutableStateOf("") }
    val listener = remember { Listener(ctx) }
    DisposableEffect(Unit) { onDispose { listener.stop() } }
    val startDictation = {
        listening = true
        micNote = ""
        listener.start(
            onPartialText = { msg = it },
            onText = {
                if (it.isNotBlank()) msg = it
                listening = false
            },
            onFail = { code ->
                listening = false
                if (code != Listener.NO_MATCH && code != Listener.TIMEOUT) {
                    micNote = "Reconnaissance vocale indisponible (vérifie ta connexion)."
                }
            }
        )
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startDictation()
    }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        focusedBorderColor = Ink,
        unfocusedBorderColor = Ink.copy(alpha = 0.4f),
        cursorColor = Accent
    )
    if (micNote.isNotEmpty()) {
        Text(
            micNote,
            color = Color(0xFFFF5252),
            fontFamily = Mono,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = msg,
            onValueChange = { msg = it },
            placeholder = { Text("Écris à JARVIS…", color = Color.Gray, fontFamily = Mono, fontSize = 13.sp) },
            shape = RoundedCornerShape(26.dp),
            colors = fieldColors,
            maxLines = 4,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .clickable {
                    if (listening) {
                        listener.stop()
                        listening = false
                    } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        startDictation()
                    } else {
                        micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                val tint = if (listening) Accent else Ink
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * 0.34f, 0f),
                    size = Size(w * 0.32f, h * 0.6f),
                    cornerRadius = CornerRadius(w * 0.16f, w * 0.16f),
                    style = if (listening) androidx.compose.ui.graphics.drawscope.Fill else Stroke(width = 3f)
                )
                drawLine(color = tint, start = Offset(w * 0.5f, h * 0.68f), end = Offset(w * 0.5f, h * 0.92f), strokeWidth = 3f, cap = StrokeCap.Round)
                drawLine(color = tint, start = Offset(w * 0.3f, h * 0.92f), end = Offset(w * 0.7f, h * 0.92f), strokeWidth = 3f, cap = StrokeCap.Round)
            }
        }
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Accent)
                .clickable {
                    if (busy) {
                        onStop()
                    } else if (msg.isNotBlank()) {
                        onSend(msg)
                        msg = ""
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                if (busy) {
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(w * 0.2f, h * 0.2f),
                        size = Size(w * 0.6f, h * 0.6f),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                } else {
                    drawLine(color = Color.White, start = Offset(w / 2, h * 0.88f), end = Offset(w / 2, h * 0.14f), strokeWidth = 5f, cap = StrokeCap.Round)
                    drawLine(color = Color.White, start = Offset(w / 2, h * 0.14f), end = Offset(w * 0.2f, h * 0.46f), strokeWidth = 5f, cap = StrokeCap.Round)
                    drawLine(color = Color.White, start = Offset(w / 2, h * 0.14f), end = Offset(w * 0.8f, h * 0.46f), strokeWidth = 5f, cap = StrokeCap.Round)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  MENU ☰ : discussions + accès aux paramètres                         */
/* ------------------------------------------------------------------ */

@Composable
private fun DrawerContent(
    ui: MainViewModel.Ui,
    onNew: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit,
    onSettings: () -> Unit
) {
    Column(
        Modifier
            .fillMaxHeight()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Text("J.A.R.V.I.S.", color = Ink, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 6.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            "＋  Nouvelle discussion",
            color = Color.White, fontFamily = Mono, fontSize = 14.sp,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onNew)
                .padding(vertical = 12.dp, horizontal = 8.dp)
        )
        Spacer(Modifier.height(10.dp))
        Text("DISCUSSIONS", color = Color.Gray, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        if (ui.chats.isEmpty()) {
            Text("Aucune discussion pour l’instant.", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
        }
        LazyColumn(Modifier.weight(1f)) {
            items(ui.chats, key = { it.id }) { c -> ChatRow(c, c.id == ui.currentId, onOpen, onDelete) }
        }
        Text(
            "Paramètres  ›",
            color = Color.White, fontFamily = Mono, fontSize = 14.sp,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onSettings)
                .padding(vertical = 14.dp, horizontal = 8.dp)
        )
    }
}

@Composable
private fun ChatRow(c: Chat, current: Boolean, onOpen: (String) -> Unit, onDelete: (String) -> Unit) {
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(armed) {
        if (armed) {
            delay(3000)
            armed = false
        }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            c.title,
            color = if (current) Accent else Color.White,
            fontFamily = Mono,
            fontSize = 13.sp,
            maxLines = 1,
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .clickable { onOpen(c.id) }
                .padding(vertical = 12.dp, horizontal = 8.dp)
        )
        Text(
            if (armed) "Sûr ?" else "✕",
            color = Color.Gray,
            fontFamily = Mono,
            fontSize = 13.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable {
                    if (armed) {
                        onDelete(c.id)
                    } else {
                        armed = true
                    }
                }
                .padding(12.dp)
        )
    }
}

/* ------------------------------------------------------------------ */
/*  PARAMÈTRES : état, IA, automatisations, mémoire, affichage          */
/* ------------------------------------------------------------------ */

@Composable
private fun SettingsScreen(ui: MainViewModel.Ui, vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var micOk by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }
    var keyText by remember { mutableStateOf("") }
    var editKey by remember { mutableStateOf(false) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        focusedBorderColor = Ink,
        unfocusedBorderColor = Ink.copy(alpha = 0.4f),
        cursorColor = Accent
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "‹  RETOUR",
                color = Ink, fontFamily = Mono, fontSize = 13.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onBack)
                    .padding(vertical = 10.dp, horizontal = 6.dp)
            )
            Spacer(Modifier.weight(1f))
            Text("PARAMÈTRES", color = Color.White, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 4.sp)
        }
        Spacer(Modifier.height(14.dp))

        Section("ÉTAT") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip("RÉSEAU", if (ui.online) "EN LIGNE" else "HORS LIGNE", ui.online, Modifier.weight(1f))
                val b = ui.battery
                val battery = if (b.percent < 0) "N/D" else "${b.percent} %" + if (b.charging) " · charge" else ""
                Chip("BATTERIE", battery, b.percent < 0 || b.percent > 15, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip(
                    "MICRO",
                    if (micOk) "AUTORISÉ · inactif" else "TOUCHER POUR AUTORISER",
                    micOk,
                    Modifier.weight(1f)
                ) { if (!micOk) launcher.launch(Manifest.permission.RECORD_AUDIO) }
                val (iaText, iaOk) = when {
                    !ui.hasKey -> "NON CONFIGURÉE" to false
                    ui.aiOk == true -> "CONNECTÉE" to true
                    ui.aiOk == false -> "ERREUR" to false
                    else -> "CLÉ ENREGISTRÉE" to true
                }
                Chip("IA", iaText, iaOk, Modifier.weight(1f))
            }
        }

        Section("INTELLIGENCE ARTIFICIELLE") {
            Text(
                "Fournisseur : Gemini (offre gratuite de Google AI Studio). Claude n’est pas branché : son API est payante.",
                color = Color.Gray, fontFamily = Mono, fontSize = 12.sp
            )
            Spacer(Modifier.height(10.dp))
            if (!ui.hasKey || editKey) {
                Text("Colle ta clé (elle reste sur ce téléphone) :", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = keyText,
                    onValueChange = { keyText = it },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        vm.saveKey(keyText)
                        keyText = ""
                        editKey = false
                    },
                    border = BorderStroke(1.dp, Ink),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ENREGISTRER LA CLÉ", fontFamily = Mono, fontSize = 13.sp) }
            } else {
                Text("Clé enregistrée.", color = Ink, fontFamily = Mono, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Changer la clé",
                    color = Color.Gray, fontFamily = Mono, fontSize = 12.sp,
                    modifier = Modifier.clickable { editKey = true }
                )
            }
            if (ui.note.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    ui.note,
                    color = if (ui.aiOk == false) Color(0xFFFF5252) else Ink,
                    fontFamily = Mono, fontSize = 12.sp
                )
            }
        }

        Section("AUTOMATISATIONS · ACTIVES") {
            Text(
                "Écris ou dis ces commandes dans la discussion. Ce que JARVIS a vraiment fait est toujours indiqué dans sa réponse.",
                color = Color.Gray, fontFamily = Mono, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            listOf(
                "« Ouvre WhatsApp » : lance une application installée",
                "« Ouvre YouTube et recherche des tutoriels Android »",
                "« Cherche … sur Google »",
                "« Mets une alarme à 7h30 » (réglée via l’horloge, vérifie-la ensuite)",
                "« Minuteur de 5 minutes »",
                "« Ouvre les paramètres Wi-Fi » (ou Bluetooth, batterie, son…)",
                "« Itinéraire vers … » : ouvre les cartes",
                "« Appelle 0812345678 » : ouvre le clavier, sans appeler",
                "« Va sur exemple.com » : ouvre le navigateur",
                "« Souviens-toi que … » / « Que sais-tu de moi ? » / « Oublie tout »"
            ).forEach {
                Text("•  $it", color = Color.White, fontFamily = Mono, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Pas encore : routines (applications de travail), contacts, contrôle à l’intérieur d’autres applications.",
                color = Color.Gray, fontFamily = Mono, fontSize = 11.sp
            )
        }

        Section("VOIX") {
            ToggleRow("Lire les réponses à voix haute", ui.autoRead) { vm.setAutoRead(it) }
            Spacer(Modifier.height(10.dp))
            Text("Vitesse de la voix", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Lente" to 0.8f, "Normale" to 1.0f, "Rapide" to 1.25f).forEach { (label, v) ->
                    val on = kotlin.math.abs(ui.speed - v) < 0.01f
                    OutlinedButton(
                        onClick = { vm.setSpeed(v) },
                        border = BorderStroke(1.dp, if (on) Accent else Ink.copy(alpha = 0.3f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = if (on) Accent else Ink),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(label, fontFamily = Mono, fontSize = 12.sp) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Le bouton micro dicte ton message. L’icône d’appel (en haut) lance une conversation vocale.",
                color = Color.Gray, fontFamily = Mono, fontSize = 11.sp
            )
        }

        Section("MÉMOIRE") {
            ToggleRow("Mémoire activée", ui.memoryOn) { vm.setMemoryOn(it) }
            Spacer(Modifier.height(8.dp))
            Text(
                "Dis « souviens-toi que … » dans la discussion pour ajouter un souvenir. Ils restent sur ce téléphone.",
                color = Color.Gray, fontFamily = Mono, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            if (ui.memories.isEmpty()) {
                Text("Aucun souvenir pour l’instant.", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp)
            }
            ui.memories.forEachIndexed { i, m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(m, color = Color.White, fontFamily = Mono, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(
                        "✕",
                        color = Color.Gray,
                        fontFamily = Mono,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { vm.deleteMemory(i) }
                            .padding(10.dp)
                    )
                }
            }
            if (ui.memories.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { vm.clearMemories() },
                    border = BorderStroke(1.dp, Ink.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("TOUT OUBLIER", fontFamily = Mono, fontSize = 13.sp) }
            }
        }

        Section("DISCUSSIONS") {
            var armedClear by remember { mutableStateOf(false) }
            LaunchedEffect(armedClear) {
                if (armedClear) {
                    delay(4000)
                    armedClear = false
                }
            }
            OutlinedButton(
                onClick = {
                    if (armedClear) {
                        vm.clearAllChats()
                        armedClear = false
                    } else {
                        armedClear = true
                    }
                },
                border = BorderStroke(1.dp, if (armedClear) Color(0xFFFF5252) else Ink.copy(alpha = 0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = if (armedClear) Color(0xFFFF5252) else Ink),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    if (armedClear) "TOUCHER ENCORE POUR CONFIRMER" else "EFFACER TOUTES LES DISCUSSIONS",
                    fontFamily = Mono, fontSize = 13.sp
                )
            }
        }

        Section("AFFICHAGE") {
            OutlinedButton(
                onClick = vm::cycleDemo,
                border = BorderStroke(1.dp, Ink),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) { Text("DÉMO DES ÉTATS (test visuel)", fontFamily = Mono, fontSize = 13.sp) }
            if (ui.demo != null) {
                Spacer(Modifier.height(6.dp))
                Text("État affiché : ${ui.demo.label}", color = ui.demo.color, fontFamily = Mono, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp)
            .border(1.dp, Ink.copy(alpha = 0.3f), shape)
            .padding(12.dp)
    ) {
        Text(title, color = Ink, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun Chip(
    title: String,
    value: String,
    ok: Boolean,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val color = if (ok) Ink else Color(0xFFFF5252)
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .background(Color(0x0FFFFFFF), shape)
            .border(1.dp, color.copy(alpha = 0.5f), shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = Color.Gray, fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = color, fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Case volontairement inactive : elle indique la phase où la fonction sera construite. */
@Composable
private fun Soon(title: String, phase: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = Color(0x88FFFFFF), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp)
            Text(phase, color = Color.DarkGray, fontFamily = Mono, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontFamily = Mono, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = Accent,
                checkedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFF2A2A2A),
                uncheckedThumbColor = Color.Gray,
                uncheckedBorderColor = Color(0xFF444444)
            )
        )
    }
}
