package com.jarvis.ai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/** Lit un texte à voix haute avec la voix du téléphone (gratuit, sans Internet). */
class Speaker(ctx: Context, private val speedProvider: () -> Float) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pendingText: String? = null
    private var pendingDone: (() -> Unit)? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.FRENCH)
                ready = true
                val t = pendingText
                if (t != null) {
                    val d = pendingDone
                    pendingText = null
                    pendingDone = null
                    speak(t, d)
                }
            } else {
                // Voix indisponible : on rend la main tout de suite.
                val d = pendingDone
                pendingText = null
                pendingDone = null
                if (d != null) main.post { d() }
            }
        }
    }

    private fun clean(text: String): String =
        text.replace(Regex("[*#_`>]"), "").replace(Regex("\\s+"), " ").trim().take(3500)

    fun speak(text: String, whenDone: (() -> Unit)? = null) {
        val engine = tts
        if (!ready || engine == null) {
            pendingText = text
            pendingDone = whenDone
            return
        }
        val id = UUID.randomUUID().toString()
        engine.setSpeechRate(speedProvider())
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                if (utteranceId == id && whenDone != null) main.post { whenDone() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == id && whenDone != null) main.post { whenDone() }
            }
        })
        engine.speak(clean(text), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stop() {
        pendingText = null
        pendingDone = null
        tts?.stop()
    }

    fun shutdown() {
        pendingText = null
        pendingDone = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
