package com.jarvis.ai.core

import androidx.compose.ui.graphics.Color

/** Les 7 états du noyau holographique. Chaque état change couleur, vitesse et ondes. */
enum class JarvisState(
    val label: String,
    val color: Color,
    val spinMs: Int,
    val pulseMs: Int,
    val wave: Float
) {
    VEILLE("VEILLE", Color(0xFF9E9E9E), 26000, 3600, 0f),
    ECOUTE("ÉCOUTE", Color(0xFFFFFFFF), 9000, 900, 1f),
    ANALYSE("ANALYSE", Color(0xFFD97757), 2600, 1400, 0.25f),
    REPONSE("RÉPONSE", Color(0xFFE6E6E6), 12000, 650, 0.8f),
    EXECUTION("EXÉCUTION", Color(0xFF6FCF97), 5000, 1000, 0.4f),
    ERREUR("ERREUR", Color(0xFFFF5252), 8000, 500, 0f),
    HORS_LIGNE("HORS LIGNE", Color(0xFF5A5A5A), 42000, 5200, 0f)
}
