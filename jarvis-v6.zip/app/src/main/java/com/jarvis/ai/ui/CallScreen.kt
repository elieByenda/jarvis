package com.jarvis.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.ai.MainViewModel
import com.jarvis.ai.core.JarvisState
import com.jarvis.ai.voice.Listener
import com.jarvis.ai.voice.Speaker
import kotlinx.coroutines.delay

private enum class CallPhase { LISTEN, THINK, SPEAK }

private val Mono = FontFamily.Monospace

/**
 * Mode appel : seulement l'hologramme. Tu parles, J.A.R.V.I.S. répond à voix haute,
 * puis il t'écoute de nouveau, jusqu'à ce que tu raccroches.
 */
@Composable
fun CallScreen(ui: MainViewModel.Ui, vm: MainViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val uiNow by rememberUpdatedState(ui)
    val closeNow by rememberUpdatedState(onClose)

    val listener = remember { Listener(ctx) }
    val speaker = remember { Speaker(ctx) { uiNow.speed } }

    var phase by remember { mutableStateOf(CallPhase.LISTEN) }
    var tick by remember { mutableStateOf(0) }
    var fails by remember { mutableStateOf(0) }
    var heard by remember { mutableStateOf("") }
    var shown by remember { mutableStateOf("") }
    var problem by remember { mutableStateOf("") }
    var sawBusy by remember { mutableStateOf(false) }
    var sentCount by remember { mutableStateOf(0) }
    var micOk by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }

    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose {
            view.keepScreenOn = false
            listener.stop()
            speaker.shutdown()
        }
    }

    LaunchedEffect(Unit) {
        if (!micOk) launcher.launch(Manifest.permission.RECORD_AUDIO)
    }

    // 1) ÉCOUTE
    LaunchedEffect(phase, tick, micOk) {
        if (phase != CallPhase.LISTEN) return@LaunchedEffect
        if (!micOk) {
            problem = "Autorise le micro pour parler à J.A.R.V.I.S."
            return@LaunchedEffect
        }
        if (!uiNow.hasKey) {
            problem = "Ajoute d’abord ta clé IA dans les paramètres."
            return@LaunchedEffect
        }
        problem = ""
        delay(350)
        heard = ""
        listener.start(
            onPartialText = { heard = it },
            onText = { text ->
                val t = text.trim()
                fails = 0
                if (t.isEmpty()) {
                    tick += 1
                } else if (Regex("raccroche|au revoir|fin de l.appel|termine l.appel", RegexOption.IGNORE_CASE)
                        .containsMatchIn(t)
                ) {
                    closeNow()
                } else {
                    heard = t
                    sentCount = uiNow.messages.size
                    sawBusy = false
                    phase = CallPhase.THINK
                    vm.send(t)
                }
            },
            onFail = { code ->
                if (code == Listener.NO_MATCH || code == Listener.TIMEOUT) {
                    tick += 1
                } else {
                    fails += 1
                    if (fails >= 6) {
                        problem = "La reconnaissance vocale ne répond pas. Vérifie ta connexion et l’application Google."
                    } else {
                        tick += 1
                    }
                }
            }
        )
    }

    // 2) RÉFLEXION : on attend la fin du travail de l'IA, puis on lit la réponse
    LaunchedEffect(uiNow.busy, phase) {
        if (phase != CallPhase.THINK) return@LaunchedEffect
        if (uiNow.busy) {
            sawBusy = true
        } else if (sawBusy) {
            sawBusy = false
            val last = uiNow.messages.lastOrNull()
            val text = if (last != null && !last.fromUser && uiNow.messages.size > sentCount + 1) {
                last.text
            } else {
                uiNow.note.ifEmpty { "Je n’ai pas de réponse pour l’instant." }
            }
            shown = text
            phase = CallPhase.SPEAK
            speaker.speak(text) { phase = CallPhase.LISTEN }
        }
    }

    // Sécurité : si rien ne se passe pendant 70 s, on réécoute
    LaunchedEffect(phase, tick) {
        if (phase == CallPhase.THINK) {
            delay(70_000)
            if (phase == CallPhase.THINK) phase = CallPhase.LISTEN
        }
    }

    val state = when {
        problem.isNotEmpty() -> JarvisState.ERREUR
        phase == CallPhase.LISTEN -> JarvisState.ECOUTE
        phase == CallPhase.THINK -> JarvisState.ANALYSE
        else -> JarvisState.REPONSE
    }
    val caption = when {
        problem.isNotEmpty() -> problem
        phase == CallPhase.LISTEN -> heard.ifEmpty { "Je t’écoute…" }
        phase == CallPhase.THINK -> "Je réfléchis…"
        else -> shown.take(220)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("A P P E L", color = Color.Gray, fontFamily = Mono, fontSize = 12.sp, letterSpacing = 4.sp)
        Spacer(Modifier.weight(1f))
        HoloCore(state, Modifier.fillMaxWidth(0.9f))
        Spacer(Modifier.height(14.dp))
        Text(state.label, color = state.color, fontFamily = Mono, fontSize = 18.sp, letterSpacing = 5.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            caption,
            color = Color.White,
            fontFamily = Mono,
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth()
        )
        if (phase == CallPhase.SPEAK) {
            Spacer(Modifier.height(8.dp))
            Text(
                "Toucher pour l’interrompre",
                color = Color.Gray,
                fontFamily = Mono,
                fontSize = 11.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable {
                        speaker.stop()
                        phase = CallPhase.LISTEN
                    }
                    .padding(10.dp)
            )
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(Color(0xFFE5484D))
                .clickable {
                    speaker.stop()
                    listener.stop()
                    if (uiNow.busy) vm.stop()
                    closeNow()
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(24.dp)) {
                val w = size.width
                val h = size.height
                drawLine(Color.White, Offset(w * 0.15f, h * 0.15f), Offset(w * 0.85f, h * 0.85f), strokeWidth = 5f, cap = StrokeCap.Round)
                drawLine(Color.White, Offset(w * 0.85f, h * 0.15f), Offset(w * 0.15f, h * 0.85f), strokeWidth = 5f, cap = StrokeCap.Round)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Raccrocher", color = Color.Gray, fontFamily = Mono, fontSize = 11.sp)
    }
}
